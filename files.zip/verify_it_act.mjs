// verify_it_act.mjs — integrity + content checks for the IT Act, 2000 data file.
// Usage:  node verify_it_act.mjs [path/to/it_act_2000_complete.json]
// Exit code 0 = all checks passed; 1 = at least one failure.
import { readFileSync } from "node:fs";

const file = process.argv[2] || "./it_act_2000_complete.json";
const data = JSON.parse(readFileSync(file, "utf8"));
let fails = 0, warns = 0;
const fail = (m) => { fails++; console.log("FAIL  " + m); };
const warn = (m) => { warns++; console.log("WARN  " + m); };
const ok = (m) => console.log("ok    " + m);

// 1. Expected slots, in order (125 section slots + 4 schedules = 129)
const EXPECTED = ("1 2 3 3A 4 5 6 6A 7 7A 8 9 10 10A 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 40A 41 42 " +
  "43 43A 44 45 46 47 48 49 50 51 52 52A 52B 52C 52D 53 54 55 56 57 58 59 60 61 62 63 64 " +
  "65 66 66A 66B 66C 66D 66E 66F 67 67A 67B 67C 68 69 69A 69B 70 70A 70B 71 72 72A 73 74 75 76 77 77A 77B 78 " +
  "79 79A 80 81 81A 82 83 84 84A 84B 84C 85 86 87 88 89 90 91 92 93 94 Sch1 Sch2 Sch3 Sch4").split(" ");
const ids = data.map((s) => s.id);
if (data.length !== EXPECTED.length) fail(`entry count ${data.length}, expected ${EXPECTED.length}`); else ok(`entry count ${data.length}`);
const dup = ids.filter((x, i) => ids.indexOf(x) !== i);
dup.length ? fail("duplicate ids: " + dup.join(", ")) : ok("no duplicate ids");
const missing = EXPECTED.filter((x) => !ids.includes(x));
missing.length ? fail("missing ids: " + missing.join(", ")) : ok("no missing ids");
const extra = ids.filter((x) => !EXPECTED.includes(x));
extra.length ? fail("unexpected ids: " + extra.join(", ")) : ok("no unexpected ids");
if (JSON.stringify(ids) !== JSON.stringify(EXPECTED)) fail("ids not in statutory order"); else ok("ids in statutory order");

// 2. Field-level checks
const REQ = ["id", "chapter", "title", "text", "amendments", "explanation", "status", "cases"];
const REPEALED = new Set("20 49 50 51 52 52A 52B 52C 53 54 56 66A 91 92 93 94 Sch3 Sch4".split(" "));
const CHAPTERS = new Set("I II III IV V VI VII VIII IX X XI XII XIIA XIII SCHEDULES".split(" "));
for (const s of data) {
  for (const k of REQ) if (!(k in s)) fail(`${s.id}: missing field "${k}"`);
  if (!CHAPTERS.has(s.chapter)) fail(`${s.id}: bad chapter "${s.chapter}"`);
  if (!Array.isArray(s.amendments)) fail(`${s.id}: amendments not an array`);
  if (!Array.isArray(s.cases)) fail(`${s.id}: cases not an array`);
  if (!s.explanation || s.explanation.length < 40) fail(`${s.id}: explanation missing/too short`);
  const shouldRepeal = REPEALED.has(s.id);
  if (shouldRepeal && s.status !== "repealed") fail(`${s.id}: should be status "repealed"`);
  if (!shouldRepeal && s.status !== "in-force") fail(`${s.id}: should be status "in-force"`);
  if (shouldRepeal && s.text !== "[Omitted.]") fail(`${s.id}: repealed entry text should be "[Omitted.]"`);
  // extraction-artifact checks (the in-force text must be clean)
  if (!shouldRepeal) {
    const t = s.text;
    if (/[―‖]/.test(t)) fail(`${s.id}: raw PDF quote glyphs ―‖ present`);
    if (/[\[\]]/.test(t) && !s.id.startsWith("Sch")) fail(`${s.id}: stray square bracket (amendment marker?)`);
    if (/\*\s?\*/.test(t)) fail(`${s.id}: omission asterisks present`);
    if (/ {2,}/.test(t)) fail(`${s.id}: double spaces`);
    if (/\b(THE|CHAPTER)\s*$/.test(t)) fail(`${s.id}: trailing chapter-heading fragment`);
    if (/\s\d\s*$/.test(t) || /\n\d+\n/.test(t)) fail(`${s.id}: stray footnote number`);
    if (/sub-\s+section/.test(t)) fail(`${s.id}: broken hyphenation "sub- section"`);
  }
  // cases
  for (const c of s.cases) {
    for (const k of ["name", "cite", "year", "ratio", "url"]) if (!c[k]) fail(`${s.id}: case "${c.name}" missing ${k}`);
    if (c.url && !/^https:\/\/indiankanoon\.org\/doc\/\d+\/$/.test(c.url)) fail(`${s.id}: case "${c.name}" url not an Indian Kanoon doc URL`);
    if (typeof c.year !== "number") fail(`${s.id}: case "${c.name}" year must be a number`);
  }
  const names = s.cases.map((c) => c.name);
  if (new Set(names).size !== names.length) fail(`${s.id}: same case listed twice in one section`);
}

// 3. Content spot-checks — current law (Jan Vishwas Act 2023, in force for IT Act from 30-11-2023)
const T = Object.fromEntries(data.map((s) => [s.id, s]));
const has = (id, str) => T[id].text.includes(str) ? ok(`${id} contains: ${str.slice(0, 60)}`) : fail(`${id} should contain: ${str}`);
const hasNot = (id, str) => !T[id].text.includes(str) ? ok(`${id} free of: ${str.slice(0, 60)}`) : fail(`${id} still contains outdated text: ${str}`);
has("33", "shall be liable to penalty which may extend to five lakh rupees");
hasNot("33", "liable to a penalty which");
has("44", "not exceeding fifteen lakh rupees for each such failure");
has("44", "not exceeding fifty thousand rupees for every day");
has("44", "not exceeding one lakh rupees for every day");
has("45", "rules, regulations, directions or orders");
has("45", "(a) ten lakh rupees, by an intermediary, company or body corporate; or");
hasNot("45", "twenty-five thousand");
has("46", "adjudging under this Act");
hasNot("46", "injury or damage");
has("67C", "liable to penalty which may extend to twenty-five lakh rupees");
has("68", "liable to penalty which may extend to twenty-five lakh rupees");
has("69B", "one year or shall be liable to fine which may extend to one crore rupees, or with both");
has("70B", "fine which may extend to one crore rupees");
has("72", "liable to penalty which may extend to five lakh rupees");
has("72A", "liable to penalty which may extend to twenty-five lakh rupees");
T["72A"].title.startsWith("Penalty") ? ok("72A title starts with Penalty") : fail("72A title should start with 'Penalty'");
has("43A", "sensitive personal data or information"); // still in force until DPDP s.44(2) commences
T["43A"].amendments.some((a) => a.includes("PROSPECTIVE")) ? ok("43A carries DPDP prospective-omission note") : fail("43A missing DPDP note");
has("48", "Telecom Disputes Settlement and Appellate Tribunal");

// Case-count lock: exactly the verified set, nothing added
const EXPECTED_CASES = 11;
const totalCases = data.reduce((n, s) => n + s.cases.length, 0);
totalCases === EXPECTED_CASES ? ok(`case count locked at ${EXPECTED_CASES}`) : fail(`case count ${totalCases}, expected exactly ${EXPECTED_CASES} verified cases`);

// 4. Summary
const caseCount = data.reduce((n, s) => n + s.cases.length, 0);
const secsWithCases = data.filter((s) => s.cases.length).map((s) => s.id);
console.log(`\nCases: ${caseCount} across ${secsWithCases.length} sections (${secsWithCases.join(", ")})`);
console.log(`In force: ${data.filter((s) => s.status === "in-force").length} | Repealed/omitted: ${data.filter((s) => s.status === "repealed").length}`);
console.log(fails ? `\n${fails} FAILURE(S), ${warns} warning(s)` : `\nALL CHECKS PASSED (${warns} warning(s))`);
process.exit(fails ? 1 : 0);
