# Nyaya-Seekho — Integrate the complete Information Technology Act, 2000

## Files in this hand-off
1. `it_act_2000_complete.json` — the ONLY data file to merge. 129 entries: sections 1–94 (125 section slots) + Schedules I–IV, in statutory order. It **replaces** any previously staged `sections_1_42.json`; do not merge both.
2. `verify_it_act.mjs` — integrity/content verifier. Must pass before and after integration.

## Rules (non-negotiable)
- Statute `text` fields are final and verbatim. Do not reword, "fix", reflow or re-punctuate them.
- Add **only** the 11 case entries already inside the data file. Do not add, research or "complete" any other cases.
- Do not change any `status`, `amendments` or `explanation` text.

## Steps
1. Run `node verify_it_act.mjs it_act_2000_complete.json` and confirm `ALL CHECKS PASSED`. If anything fails, stop and report — do not patch the data yourself.
2. Look at how existing acts are stored in `App.jsx` / the data folder (e.g. the Registration Act or Constitution entries). Convert this JSON into that same structure (JS module/export shape, act metadata such as act name "The Information Technology Act, 2000", act number "Act No. 21 of 2000", enactment date 9 June 2000).
3. **Schedules:** this file uses ids `Sch1`–`Sch4` with `chapter: "SCHEDULES"`. If an existing act in the app already stores schedules under a different id or chapter convention, rename to match that convention and update the `EXPECTED` list in the verifier accordingly. If no act stores schedules yet, keep these ids and make sure the UI renders them after section 94.
4. **Chapter labels:** chapters are roman numerals (`I`–`XIII`, plus `XIIA` for Chapter XIIA containing only s. 79A). Map to chapter titles exactly as the app does for other acts:
   I Preliminary · II Digital Signature and Electronic Signature · III Electronic Governance · IV Attribution, Acknowledgment and Despatch of Electronic Records · V Secure Electronic Records and Secure Electronic Signature · VI Regulation of Certifying Authorities · VII Electronic Signature Certificates · VIII Duties of Subscribers · IX Penalties, Compensation and Adjudication · X The Appellate Tribunal · XI Offences · XII Intermediaries Not to be Liable in Certain Cases · XIIA Examiner of Electronic Evidence · XIII Miscellaneous.
5. Case objects use the standard schema (`name`, `cite`, `year`, `ratio`, `url`). Two cases also carry the existing `decidedUnder` / `continuityNote` flags — Google India v. Visaka (s. 79, pre-2009 version of the section) and Awadhesh Kumar Paras Nath Pathak (s. 66, decided with reference to the IPC) — render them the same way as for pre-BSA cases. High Court decisions (Syed Asifuddin — Andhra Pradesh HC; Myspace — Delhi HC; Awadhesh Kumar — Bombay HC Full Bench) name the court inside `cite`. Shreya Singhal appears under 66A, 69A and 79 and Sharat Babu Digumarti under 67 and 81, each with a section-specific ratio; that is intentional. If the app's duplicate-check is global rather than per-section, make it per-section (same case under different sections is allowed; the same case twice under one section is not).
6. Repealed/omitted entries (`status: "repealed"`, text `[Omitted.]`) must display like existing repealed sections (e.g. Registration Act / Limitation Act repealed slots).
7. Run the project's existing data-integrity checks (no duplicate/missing IDs across acts), then build.
8. Re-run `verify_it_act.mjs` against the integrated data (point it at an exported JSON of the IT Act entries if needed) and confirm it still passes.
9. Export the zip as usual.

## Expected verifier summary
```
Cases: 11 across 9 sections (65, 66, 66A, 67, 67B, 69A, 79, 81, 85)
In force: 111 | Repealed/omitted: 18
ALL CHECKS PASSED
```

## Background (for the commit message / changelog)
- Text reflects: IT (Amendment) Act 2008 (Act 10 of 2009); Finance Act 2017 (TDSAT replaces the Cyber Appellate Tribunal); Jan Vishwas (Amendment of Provisions) Act 2023, IT Act amendments in force from 30-11-2023 (ss. 33, 44, 45, 46, 66A omitted, 67C, 68, 69B, 70B, 72, 72A).
- Section 33 correction in the earlier 1–42 batch: "liable to a penalty" → "liable to penalty" (the Jan Vishwas substituted words are "liable to penalty which may extend to five lakh rupees").
- Prospective, not yet in force: DPDP Act 2023 s. 44(2) (omits s. 43A and s. 87(2)(ob); amends the s. 81 proviso) — commences on or about 13-05-2027. Recorded as notes; text unchanged.
- The IT Act is not in the schedule of the Jan Vishwas (Amendment of Provisions) Act, 2026.
